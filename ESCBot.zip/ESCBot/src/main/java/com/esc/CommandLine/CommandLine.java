package com.esc.CommandLine;

import static org.kohsuke.args4j.ExampleMode.ALL;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;
import java.io.IOException;



/**
 * Sample program that shows how you can use args4j.
 *
 * @author
 *      Kohsuke Kawaguchi (kk@kohsuke.org)
 */
public class CommandLine {

    @Option(name="-apiKey",usage="used to add prefix")
    private String hiddenStr2 = "(default value)";



    public static void main(String[] args) throws IOException {
        new CommandLine().doMain(args);
    }

    public void doMain(String[] args) throws IOException {
        CmdLineParser parser = new CmdLineParser(this);


        parser.setUsageWidth(80);

        try {
            // parse the arguments.
            parser.parseArgument(args);

            // you can parse additional arguments if you want.
            // parser.parseArgument("more","args");

            // after parsing arguments, you should check
            // if enough arguments are given.
            //arguments.add("-custom");


        } catch (CmdLineException e) {
            // if there's a problem in the command line,
            // you'll get this exception. this will report
            // an error message.
            System.err.println(e.getMessage());
            System.err.println("java SampleMain [options...] arguments...");
            // print the list of available options
            parser.printUsage(System.err);
            System.err.println();

            // print option sample. This is useful some time
            System.err.println("  Example: java SampleMain" + parser.printExample(ALL));

            return;
        }
    }
}
