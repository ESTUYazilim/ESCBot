# ESCBot
Discord bot of ESTU Software Community
